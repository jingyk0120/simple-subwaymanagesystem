package cn.itcase.service;

import cn.itcase.domain.PageBean;
import cn.itcase.domain.subwayinfo;

import java.util.List;
import java.util.Map;

/**
 *业务接口
 */
public interface UserService {
    /**
     * 查询所有信息
     * @return
     */
    public List<subwayinfo> findAll();

    /**
     * 分页条件查询
     * @param currentPage
     * @param rows
     * @param condition
     * @return
     */
    PageBean<subwayinfo> findUserByPage(String currentPage, String rows, Map<String, String[]> condition);
}
