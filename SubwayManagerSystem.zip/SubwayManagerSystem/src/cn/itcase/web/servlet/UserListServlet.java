package cn.itcase.web.servlet;

import cn.itcase.domain.subwayinfo;
import cn.itcase.service.UserService;
import cn.itcase.service.impl.UserServiceImpl;
import jdk.nashorn.internal.ir.RuntimeNode;
import sun.plugin.dom.core.Element;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserListServlet", value = "/userListServlet")
public class UserListServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      this.doGet(req,resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //调用userservice完成查询
        UserService service=new UserServiceImpl();
        List<subwayinfo> subwayinfos = service.findAll();
        req.setAttribute("subwayinfos",subwayinfos);
        req.getRequestDispatcher("/list.jsp").forward(req,resp);

    }
}
