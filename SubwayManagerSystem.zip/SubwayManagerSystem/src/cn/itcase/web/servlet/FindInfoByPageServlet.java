package cn.itcase.web.servlet;

import cn.itcase.domain.PageBean;
import cn.itcase.domain.subwayinfo;
import cn.itcase.service.UserService;
import cn.itcase.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet(name = "FindInfoByPageServlet", value = "/findInfoByPageServlet")
public class FindInfoByPageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        //1.获取参数
        String currentPage = req.getParameter("currentPage");//当前页码
        String rows = req.getParameter("rows");//每页显示的条数
        //进行一个判断
        if (currentPage ==null||"".equals(currentPage)){
            currentPage="1";
        }
        if (rows == null || "".equals(rows)){
            rows="10";
        }

        //获取条件查询的参数
        Map<String, String[]> condition = req.getParameterMap();

        //2.调用service查询
        UserService service= new UserServiceImpl();
        PageBean<subwayinfo> pb = service.findUserByPage(currentPage,rows,condition);
        //System.out.println(pb);
        //3.将PageBean存入request;
        req.setAttribute("pb",pb);
        req.setAttribute("condition",condition);//将查询条件存入request域中
        //4.转发到list.jsp
        req.getRequestDispatcher("/list.jsp").forward(req,resp);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
