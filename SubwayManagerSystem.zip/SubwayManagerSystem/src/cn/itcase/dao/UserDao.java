package cn.itcase.dao;

import cn.itcase.domain.subwayinfo;

import java.util.List;
import java.util.Map;

/**
 * 用户操作的Dao
 */
public interface UserDao {
    public List<subwayinfo> findALL();

    int findTotalCount(Map<String, String[]> condition);

    List<subwayinfo> findByPage(int start, int rows, Map<String, String[]> condition);
}
