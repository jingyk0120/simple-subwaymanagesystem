package cn.itcase.test;

import cn.itcase.service.UserService;
import cn.itcase.service.impl.UserServiceImpl;
import org.junit.Test;

public class UserServiceTest {
    UserService userService=new UserServiceImpl();
    @Test
    public void findAll(){
        System.out.println(userService.findAll());
    }


}
